《Redis实战》中文注释源码
======================================

这里展示的是《Redis实战》一书附带的相关源码，
原始代码来自： `github.com/josiahcarlson/redis-in-action <https://github.com/josiahcarlson/redis-in-action>`_

为了方便大家学习这些源码，
我已经将源码中的所有注释从英文翻译成了中文，
希望大家喜欢。

关于《Redis实战》的更多信息，请访问 `redisinaction.com <http://redisinaction.com>`_

.. image:: ria-cover.png 
